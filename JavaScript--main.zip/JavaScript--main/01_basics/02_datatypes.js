"use strict";//treat all JS code as newer version is a good practice to follow

// alert("hello") we are using node js not the browser

console.log(3 + 
    3)//code readibility should be high

console.log("Adarsh")

let name="Adarsh"
let age=18
let isLoggedIn=false


//numbers=>2 power 53
//bigInt=>more bigger number
//string=>""
//boolean=>true/false
//null=>standalone value
//undefined=> abhi value assigned nhi hui hai or the value is not assigned
//symbol=>unique

//objects=>

console.log(typeof("Adarsh"))//string:as it is in ""
console.log(typeof null)//object
console.log("undefined")//undefined
