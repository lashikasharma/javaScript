console.log(2>1)
console.log(2>=1)
console.log(2<1)
console.log(2==1)
console.log(2!=1)


console.log("2">1)
console.log("02">1)

console.log(null>0)
console.log(null===0)
console.log(null>=0)
//we should avoid these types of comparisions in js


console.log(undefined==0)
console.log(undefined>0)
console.log(undefined<0)
//we should avoid these types of comparisions in js

//====
console.log("2"==2)
console.log("2"===2)

